# forgefrenzy
A collection of tools to nurture your addiction to Dwarven Forge

[![License](https://img.shields.io/pypi/l/forgefrenzy)](https://pypi.org/project/forgefrenzy/)[![Github license](https://img.shields.io/github/license/lawnmowerlatteforgefrenzy.svg "License")](https://github.com/lawnmowerlatteforgefrenzy/blob/master/LICENSE)

[![Open issues](https://img.shields.io/github/issues/lawnmowerlatteforgefrenzy.svg "Open issues")](https://github.com/lawnmowerlatteforgefrenzy/issues)
[![Closed issues](https://img.shields.io/github/issues-closed/lawnmowerlatteforgefrenzy.svg "Closed issues")](https://github.com/lawnmowerlatteforgefrenzy/issues?utf8=✓&q=is%3Aissue+is%3Aclosed)

[![Open Pull Requests](https://img.shields.io/github/issues-pr/lawnmowerlatteforgefrenzy.svg "Open Pull Requests")](https://github.com/lawnmowerlatteforgefrenzy/pulls)
[![Closed Pull Requests](https://img.shields.io/github/issues-pr-closed/lawnmowerlatteforgefrenzy.svg "Closed Pull Requests")](https://github.com/lawnmowerlatteforgefrenzy/pulls?utf8=✓&q=is%3Apr+is%3Aclosed)
